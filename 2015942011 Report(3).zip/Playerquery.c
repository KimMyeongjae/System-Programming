#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include "player.h"

/* 선수번호를 입력받아 해당 선수의 레코드를 파일에서 읽어 출력한다. */
int main(int argc, char *argv[])
{
	    int fd, id;
	        char c;
		    struct player rec;

		       if (argc < 2) {
			               fprintf(stderr,  "사용법 : %s file\n", argv[0]);
				               exit(1);
					          }

		          if ((fd = open(argv[1], O_RDONLY)) == -1) {
				          perror(argv[1]);
					          exit(2);
						      }

			      do {
				              printf("선수번호 입력(1500~):");
					              if (scanf("%d", &id) == 1) {
							                  lseek(fd, (id-START_ID)*sizeof(rec), SEEK_SET);
									              if ((read(fd, &rec, sizeof(rec)) > 0) && (rec.id != 0)) 
											                      printf("학번:%d\t 이름:%s\t 소속팀:%s\n", 
											                              rec.id, rec.name, rec.team);
										                  else printf("%d번의 선수 없음\n", id);

						      }
						              else printf("입력 오류"); 


							              printf("계속하겠습니까?(Y/N)");
								              scanf(" %c", &c);
									          } while (c == 'Y' || c == 'y');
			         
			          close(fd);
			          exit(0);
}

