#define MAX 24
#define START_ID 1500
struct player {
	   char name[MAX],team[MAX];
	      int id;	        


};

