#define MAXLINE 100
void copy(char from[], char to[]);
