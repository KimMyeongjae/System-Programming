class test{
	publc static void main(String args[]) {
	  System.out.println("Hello JAVA world\m");
	}
}
