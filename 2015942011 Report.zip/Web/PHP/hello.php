<?
echo "hello PHP world!!";
?>
