#include <sys/types.h> 
#include <sys/stat.h>
#include <dirent.h>
#include <pwd.h>
#include <grp.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

char type(mode_t);
char *perm(mode_t);
void al(char*, char*, struct stat*);
void printFile(char*, char*, struct stat*);
/* 디렉토리 내용을 자세히 리스트한다. */
int main(int argc, char *argv[]) 
{
		    DIR *dp;
		    char *dir;
		    struct stat st;
	            struct dirent *d;
		    char path[BUFSIZ+1];

		
		    if (argc == 1)  dir = ".";
                    
       	            if ((dp = opendir(dir)) == NULL)  // 디렉토리 열기 
		        perror(dir);

     	            while ((d = readdir(dp)) != NULL) {	// 디렉토리 내의 각 파일에 대해
		           sprintf(path, "%s/%s", dir, d->d_name); // 파일 경로명 만들기 
																							 			         if (lstat(path, &st) < 0) 	// 파일 상태 정보 가져오기  
		                perror(path);
		            else{
				if(argc ==1){
				            if(strcmp(d->d_name,".")==0||strcmp(d->d_name,"..")==0)												 				       	 continue;
					  																			 				         printFile(path, d->d_name, &st);  																		              continue;																						}																						        }	
																										 }
																										 printf("\n");
		    closedir(dp);																	
		    exit(0);
}
void printFile(char *pathname, char *file, struct stat *st){
		printf("%s  ", file);
}


